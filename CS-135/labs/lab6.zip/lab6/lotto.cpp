//
//  lotto.cpp
//  labs
//
//  Created by Lucie Chevreuil on 7/13/23.
//  Lab 6 Part 1, CS-135
//
// PSEUDOCODE
//
// 1) void function displayMenu
// fx input n/a
// fx output n/a
// -----------------------------------------------------------------------
// Output LITTLETON CITY LOTTO MODEL:
// Output ------------------------
// Output 1) Play Lotto
// Output 0) Quit Program
// Output Please make a selection:
// ###########################################################################################

// 2) void function displayMenu
// fx input n/a
// fx output n/a
// -----------------------------------------------------------------------

#include "lotto.h"
#include <iostream>
#include <vector>


using namespace std;

// ###########################################################################################
// FUNCTION 1
// ###########################################################################################
void displayMenu() {
    cout << "LITTLETON CITY LOTTO MODEL:" << endl;
    cout << "---------------------------" << endl;
    cout << "1) Play Lotto" << endl;
    cout << "0) Quit Program" << endl;
    cout << "Please make a selection: ";
}

// ###########################################################################################
// FUNCTION 2
// ###########################################################################################
void getLottoPicks(int nums[]) {
    for (int i = 0; i < sizeof(nums) - 1; i++) {
            int number;
            do {
                cout << "Enter pick #" << i + 1 << ": ";
                cin >> number;

                // Check if the number is within the valid range
                if (number < 1 || number > 40) {
                    cout << "Invalid entry" << endl;
                    continue;
                }
                
                if(noDuplicates(nums, number)) {
                    cout << "Duplicate entry!" << endl;
                    continue;
                }

                break;
            } while (i < sizeof(nums) - 1);

        nums[i] = number;
        }
}

// ###########################################################################################
// FUNCTION 3
// ###########################################################################################
void genWinNums(int winningNums[]) {
    
}

// ###########################################################################################
// FUNCTION 4
// ###########################################################################################
bool noDuplicates (int nums[], int num) {
    for(int i = 0; i < sizeof(nums) - 1; i++) {
        if(nums[i] == num){
            return true;
        }
    }
    return false;
}
