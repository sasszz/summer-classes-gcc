//
//  main.cpp
//  labs
//
//  Created by Lucie Chevreuil on 7/13/23.
// Lab 6 Part 1, CS-135
//
// PSEUDOCODE

#include "lotto.h"
#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main() {
    string playerName;
    int playerSelection;
    int userTicket[LOTTO_PICK_ARRAY_SIZE] = {};
    
//    int winningNums[LOTTO_PICK_ARRAY_SIZE] = {};
//    srand(13);

    cout << "Please enter your name: ";
    cin >> playerName;
    cout << endl;
    
    displayMenu();
    cin >> playerSelection;
    
    switch (playerSelection) {
        case 0:
            cout << "Quitting." << endl;
            break;
        case 1:
            getLottoPicks(userTicket);
            break;
        default:
            cout << "Invalid Selection." << endl;
            break;
    }
    return 0;
}

